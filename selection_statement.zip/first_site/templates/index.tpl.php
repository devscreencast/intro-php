<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Selection Statements</title>
</head>
<body>

<?php if($random == $guess): ?>
    You got it right random number is <?= $random ?>
<?php else: ?>
    Oh no, random number is <?= $random ?>
<?php endif; ?>
</body>
</html>