<?php
/*$score = intval(72 / 10);
$remaining = 72 % 10;*/
#90 - 95 A- AND 96 - 100 A+
#80 - 85 B- AND 86 - 89  B+
#70 - 75 C- AND 76 - 79  C+
#60 - 65 D- AND 66 - 69  D+
#F for the rest
/*if ($score >= 90 && $score <= 100 ) {
    $grade = 'A';
}
else if ( $score >= 80 && $score <= 89 ) {
    $grade = 'B';
}
else if ( $score >= 70 && $score <= 79 ) {
    $grade = 'C';
}
else if ( $score >= 60 && $score <= 69 ) {
    $grade = 'D';
}
else {
    $grade = 'F';
}*/
/*switch ($score) {
    case 9: case 10:
        $grade = 'A';
        break;
    case 8:
        $grade = 'B';
        break;
    case 7:
        $grade = 'C';
        break;
    case 6:
        $grade = 'D';
        break;
    default:
        $grade = 'F';
}*/
/*switch ($remaining) {
    case 10: case 9: case 8: case 7: case 6:
        $grade .= '+';
        break;
    case 0: case 1: case 2: case 3: case 4: case 5:
        $grade .= '-';
        break;
}
echo $grade;*/

/*#divisible by 4 but not 100 or divisible by 400
$year = 2008;

$isLeapYear = ($year % 4 == 0 && $year % 100 != 0) || ($year % 400 == 0);*/

$random = rand(1, 5) * 10;
$guess = $_GET['guess'];

require 'templates/index.tpl.php';

