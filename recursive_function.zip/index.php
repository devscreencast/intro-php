<?php
$student = array(
    'name' => 'John Doe',
    'course' => 'Software Engineering',
    'age' => 34,
    'grade' => 3.8,
    'level' => '200',
    'collections' => ['books' => 'Intro to UML', 'music' => 'rap', array(1,2)]
);
/*function arrayHelper($array)
{
    echo "<ul>";
    foreach ( $array as $attribute => $value ) {
        if (is_array( $value )) {
            echo "<li>". $attribute;
                arrayHelper($value);
            echo "</li>";
        }else {
            echo "<li> $attribute: $value </li>";
        }
    }
    echo "</ul>";
}*/

function flattenArray($array)
{
    foreach ($array as $attribute => $value)
    {
        if(is_array($value))
        {
            flattenArray($value);
        }else{
            echo "{$value} <br />";
        }
    }
}
require 'templates/index.tpl.php';

