<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recursive Functions</title>
</head>
<body>

<?php
    //arrayHelper($student);
    flattenArray($student);
?>

</body>
</html>
