<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Special Functions in PHP</title>
</head>
<body>

<?php

?>

</body>
</html>
