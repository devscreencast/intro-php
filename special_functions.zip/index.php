<?php
#IS_CALLABLE
#CALL_USER_FUNC
#CALL_USER_FUNC_ARRAY

/*function test()
{
    echo "I am test";
}

$func_name = "test";

if(is_callable($func_name, true, $name)) {
    echo "Function {$func_name} is callable {$name}";
}else{
    echo "Function {$func_name} is not callable";
}*/
/*class Food
{
    function rice()
    {
        echo "Rice";
    }
}

$obj = new Food;
$check = [$obj, 'rice'];

if (is_callable($check, true, $name)) {
    echo "Yes {$name}";
}else{
    echo "No";
}*/
/*function president($country, $name)
{
    echo "The president of {$country} is {$name} <br />";
}

call_user_func('president', "Nigeria", "Buhari M");
call_user_func('president', "America", "Donald J Trump");*/



class MenuController
{
    function setMenus($menu1, $menu2, $menu3)
    {
        echo "We have the following menus {$menu1}, {$menu2}, {$menu3}";
    }
}

$menus = new MenuController;

echo call_user_func_array([$menus, 'setMenus'], ["About Us", "Privacy Policy", "Homepage"]);

require 'templates/index.tpl.php';

