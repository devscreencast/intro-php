<?php

function divide($num1, $num2, $swap = true)
{
    if (!is_int($num1) || !is_int($num2))
    {
        return "Enter number for both argument 1 and 2";
    }
    
    if($swap && $num1 < $num2)
    {
        $temp = $num1;
        $num1 = $num2;
        $num2 = $temp;
    }
    
    return $num1 / $num2;
}


require 'templates/index.tpl.php';

