<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Custom Functions</title>
</head>
<body>

<?php
   echo divide("ytet3e", 10, false);
?>

</body>
</html>
