<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>The View</title>
</head>
<body>
<h2>List of students from template </h2>

<?php foreach ($students as $key => $value): ?>
    <ul>
        <?php if(is_array($value)): ?>
            <?php foreach ($value as $attributes => $val ): ?>
                <li> <?= $attributes ?> => <?= $val ?></li>
            <?php endforeach; ?>
            <?php else: ?>
            <li> <?= $key ?> => <?= $value ?></li>
        <?php endif; ?>
    </ul><hr />
<?php endforeach; ?>
</body>
</html>